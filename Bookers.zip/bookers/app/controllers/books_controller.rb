class BooksController < ApplicationController
  def index
    @bookers=Book.all
    @booker=Book.new
  end

  def show
    @booker=Book.find(params[:id])
  end

  def new

  end

  def create
    @booker=Book.new(booker_params)
    if @booker.save
      redirect_to book_path(@booker.id)
    else
      @bookers=Book.all
      render :index
    end
  end

  def edit
    @booker=Book.find(params[:id])
  end

  def update
    @booker = Book.find(params[:id])
    if @booker.update(booker_params)
      redirect_to book_path(@booker)
    else
      render :edit
    end
  end

  def destroy
    booker = Book.find(params[:id])
    booker.destroy
    redirect_to books_path
  end

  private
  def booker_params
    params.require(:book).permit(:title, :category, :body)
  end

end
